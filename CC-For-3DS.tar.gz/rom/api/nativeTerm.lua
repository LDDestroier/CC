-- Information on native ComputerCraft screen
local system = {
	width = 51,
	height = 19,
	cur_x = 1,
	cur_y = 1,
	cur_blink = true,
	isColor = true,
	active = true,
	palette = {
		raw = {},
		{0xF0, 0xF0, 0xF0},	-- White
		{0xF2, 0xB2, 0x33},	-- Orange
		{0xE5, 0x7F, 0xD8},	-- Magenta
		{0x99, 0xB2, 0xF2},	-- Light Blue
		{0xDE, 0xDE, 0x6C},	-- Yellow
		{0x7F, 0xCC, 0x19},	-- Lime
		{0xF2, 0xB2, 0xCC},	-- Pink
		{0x4C, 0x4C, 0x4C},	-- Gray
		{0x99, 0x99, 0x99},	-- Light Gray
		{0x4C, 0x99, 0xB2},	-- Cyan
		{0xB2, 0x66, 0xE5},	-- Purple
		{0x33, 0x66, 0xCC},	-- Blue
		{0x7F, 0x66, 0x64},	-- Brown
		{0x57, 0xA6, 0x4E},	-- Green
		{0xCC, 0x4C, 0x4C},	-- Red
		{0x19, 0x19, 0x19},	-- Black
	},
	textColor = 1,
	backColor = 16,
	textDepth = 0,
	backDepth = 0,
	buffer = {{},{},{}},
}

-- Limit number between two values

local limit = function(number, min, max)
	return math.min(math.max(number, max), min)
end

-- Reinitializes the palette's colors

local generatePalette = function()
	for i = 1, 16 do
		system.palette.raw[i] = Colors.new(
			system.palette[i][1],
			system.palette[i][2],
			system.palette[i][3]
		)
	end
end

generatePalette()

-- Translation tables for different color encodings

local hexToPalette = {}
local paletteToHex = {}

local hexToColors = {}
local colorsToHex = {}

local colorsToPalette = {}
local paletteToColors = {}

for i = 1, 16 do
	hexToPalette[("0123456789abcdef"):sub(i,i)] = i
	paletteToHex[i] = ("0123456789abcdef"):sub(i,i)

	hexToColors[("0123456789abcdef"):sub(i,i)] = 2^(i - 1)
	colorsToHex[2^(i - 1)] = ("0123456789abcdef"):sub(i,i)

	colorsToPalette[2^(i - 1)] = i
	paletteToColors[i] = 2^(i - 1)
end

-- Puts a character of specified text/background color/depth on the buffer.
local bufferPut = function(x, y, char, text, back, tDepth, bDepth)
	if x >= 1 and x <= system.width and y >= 1 and y <= system.height then
		if char == false then
			system.buffer[y][x] = nil
		else
			system.buffer[y][x] = {
				char or " ",
				text or system.textColor,
				back or system.backColor,
				tDepth or 0,
				bDepth or 0,
			}
		end
	end
end

-- Resizes the buffer and crops accordingly
local resizeBuffer = function(newWidth, newHeight)
	for y = 1, math.max(system.height, newHeight) do
		if y > newHeight then
			system.buffer[y] = nil
		else
			for x = 1, math.max(system.width, newWidth) do
				if x > newWidth then
					system.buffer[y][x] = nil
				else
					bufferPut(
						x,
						y,
						" ",
						system.textColor,
						system.backColor,
						system.textDepth,
						system.backDepth
					)
				end
			end
		end
	end
end

-- Ensures that the buffer is as large as it needs to be, and has all spaces filled.

resizeBuffer(system.width, system.height)

-- Converts hexadecimal color value to RGB

local hexToRGB = function(color)
	local red = bit32.rshift(bit32.band(color, 0xFF0000), 16)
	local green = bit32.rshift(bit32.band(color, 0xFF00), 8)
	local blue = bit32.band(color, 0xFF)
	return red, green, blue
end

-- Time to remake the whole Term API!

local nativeTerm = {
	write = function(char, tDepth, bDepth)
		for i = 1, #char do
			bufferPut(
				-1 + i + system.cur_x,
				system.cur_y,
				char:sub(i,i),
				system.textColor,
				system.backColor,
				tDepth or system.textDepth,
				bDepth or system.backDepth
			)
			system.cur_x = 1 + system.cur_x
		end
	end,

	-- Depth in term.blit needs a way to be encoded in a string

	blit = function(char, text, back)
		assert(type(char) == "string", "bad argument #1 (expected string, got " .. type(char) .. ")")
		assert(type(text) == "string", "bad argument #2 (expected string, got " .. type(text) .. ")")
		assert(type(back) == "string", "bad argument #3 (expected string, got " .. type(back) .. ")")
		assert(#char == #text and #text == #back, "Arguments must be same length")
		for i = 1, #char do
			bufferPut(
				-1 + i + system.cur_x,
				system.cur_y,
				char:sub(i,i),
				hexToPalette[text:sub(i,i)],
				hexToPalette[back:sub(i,i)],
				system.textDepth,
				system.backDepth
			)
			system.cur_x = 1 + system.cur_x
		end
	end,

	setCursorPos = function(x, y)
		assert(type(x) == "number", "bad argument #1 (expected number, got " .. type(x) .. ")")
		assert(type(y) == "number", "bad argument #2 (expected number, got " .. type(y) .. ")")
		system.cur_x = x
		system.cur_y = y
	end,

	getCursorPos = function()
		return system.cur_x, system.cur_y
	end,

	setTextColor = function(color)
		assert(type(color) == "number", "bad argument #1 (expected number, got " .. type(color) .. ")")
		if colorsToPalette[color] then
			system.textColor = colorsToPalette[color]
		else
			error("Invalid color (got " .. tostring(color) .. ")")
		end
	end,

	setBackgroundColor = function(color)
		assert(type(color) == "number", "bad argument #1 (expected number, got " .. type(color) .. ")")
		if colorsToPalette[color] then
			system.backColor = colorsToPalette[color]
		else
			error("Invalid color (got " .. tostring(color) .. ")")
		end
	end,

	setTextDepth = function(depth)
		assert(type(depth) == "number", "bad argument #1 (expected number, got " .. type(depth) .. ")")
		system.textDepth = depth
	end,

	setBackgroundDepth = function(depth)
		assert(type(depth) == "number", "bad argument #1 (expected number, got " .. type(depth) .. ")")
		system.backDepth = depth
	end,

	getTextColor = function()
		return paletteToColors[system.textColor]
	end,

	getBackgroundColor = function()
		return paletteToColors[system.backColor]
	end,

	clear = function()
		for y = 1, system.height do
			for x = 1, system.width do
				bufferPut(
					x,
					y,
					" ",
					system.textColor,
					system.backColor,
					system.textDepth,
					system.backDepth
				)
			end
		end
	end,

	clearLine = function()
		for x = 1, system.width do
			bufferPut(
				x,
				system.cur_y,
				" ",
				system.textColor,
				system.backColor,
				system.textDepth,
				system.backDepth
		end
	end,

	scroll = function(lines)
		assert(type(lines) == "number", "bad argument #1 (expected number, got " .. type(lines) .. ")")
		if lines ~= 0 then
			for y = 1, system.height do
				system.buffer[y] = (system.buffer[y] + lines) or false
			end
			resizeBuffer(system.width, system.height)
		end
	end,

	setCursorBlink = function(blink)
		system.cur_blink = blink and true or false
	end,

	getCursorBlink = function()
		return system.cur_blink
	end,

	getSize = function()
		return system.width, system.height
	end,

	isColor = function()
		return system.isColor
	end,

	getPaletteColor = function(palette)
		assert(type(palette) == "number", "bad argument #1 (expected number, got " .. type(palette) .. ")")
		if system.palette[palette] then
			return system.palette[palette][1] / 255, system.palette[palette][2] / 255 system.palette[palette][3] / 255
		else
			error("Invalid color (got " .. tostring(palette) .. ")")
		end
	end,

	setPaletteColor = function(palette, red, green, blue)
		if system.palette[palette] then
			assert(type(red) == "number", "bad argument #2 (expected number, got " .. type(red) .. ")")
			assert(type(green) == "number", "bad argument #3 (expected number, got " .. type(green) .. ")")
			assert(type(blue) == "number", "bad argument #4 (expected number, got " .. type(blue) .. ")")
			-- Using three 0-1 color values
			if green then
				system.palette[palette] = {
					limit(red, 0, 1) * 255,
					limit(green, 0, 1) * 255,
					limit(blue, 0, 1) * 255
				}
				system.palette.raw[palette] = Colors.new(table.unpack(system.palette[palette]))
			else
				-- I sure hope lpp-3ds has bit32 library...
				system.palette[palette] = {
					limit(bit32.rshift(bit32.band(red, 0xFF0000), 16), 0, 255),
					limit(bit32.rshift(bit32.band(red, 0xFF00), 8), 0, 255),
					limit(bit32.band(red, 0xFF), 0, 255)
				}
			end
		else
			error("Invalid color (got " .. tostring(palette) .. ")")
		end
	end

}

-- British spellings

nativeTerm.setPaletteColour = nativeTerm.setPaletteColor
nativeTerm.getPaletteColour = nativeTerm.getPaletteColor
nativeTerm.setTextColour = nativeTerm.setTextColor
nativeTerm.getTextColour = nativeTerm.getTextColor
nativeTerm.setBackgroundColour = nativeTerm.setBackgroundColor
nativeTerm.getBackgroundColour = nativeTerm.getBackgroundColor
nativeTerm.isColour = nativeTerm.isColor

return nativeTerm, system
