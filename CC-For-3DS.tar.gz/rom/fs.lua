-- io implementation of ComputerCraft's FS API

local fs = {}
fs.list = function(path)
	return System.listDirectory(path)
end

fs.exists = function(path)
	return System.doesFileExist(path)
end

fs.isDir = function(path)
	if System.doesFileExist(path) then
		local o = io.open(path)
		if o then
			o:close()
			return false
		else
			return true
		end
	else
		return false
	end
end

fs.isReadOnly = function(path)
	-- TO DO: Properly check if path is within rom
	return false
end

fs.getName = function(path)
	-- Fix later
end

fs.getDrive = function(path)
	-- TO DO: Properly check if path is within rom, or a virtual disk drive for later
	return "hdd"
end

fs.getSize = function(path)

end

fs.getFreeSpace = function(path)
	return System.getFreeSpace()
end

fs.makeDir = function(path)
	System.createDirectory(path)
end

fs.move = function(fromPath, toPath)
	if fs.isDir(fromPath) then
		System.renameDirectory(fromPath, toPath)
	else
		System.renameFile(fromPath, toPath)
	end
end

fs.copy = function(fromPath, toPath)
	-- Fix this
end

fs.delete = function(path)
	if fs.isDir(path) then
		System.deleteDirectory(path)
	else
		System.deleteFile(path)
	end
end

fs.combine = function(basePath, localPath)
	-- This doesn't optimize path names, but that's haaaaaard
	return basePath .. "/" .. localPath
end

fs.open = function(path, mode)
	assert(fs.exists(path), "File doesn't exist")
	local file
	if mode == "w" or mode == "wb" or mode == "a" or mode == "ab" then
		file = io.open(path, mode)
		return {
			close = function()
				file:close()
			end,
			write = function(data)
				file:write(data)
			end,
			writeLine = function(data)
				file:write(data .. "\n")
			end,
			flush = function()
				file:flush()
			end
		}
	elseif mode == "r" or mode == "rb" then
		file = io.open(path, mode)
		return {
			close = function()
				file:close()
			end,
			readLine = function()
				return file:read()
			end,
			readAll = function()
				return file:read(2^31-1)..file:read(2^31-1)	-- reads up to 4 GiB
			end
		}
	end
end

fs.find = function(path)
	local pathParts, results, curfolder = {}, {}, "/"
	for part in path:gmatch("[^/]+") do
		pathParts[#pathParts + 1] = part:gsub("*", "[^/]*")
	end
	if #pathParts == 0 then
		return {}
	end

	local prospects = fs.list(curfolder)
	for i = 1, #prospects do
		prospects[i] = {["parent"] = curfolder, ["depth"] = 1, ["name"] = prospects[i]}
	end

	while #prospects > 0 do
		local thisProspect = table.remove(prospects, 1)
		local fullPath = fs.combine(thisProspect.parent, thisProspect.name)

		if thisProspect.name == thisProspect.name:match(pathParts[thisProspect.depth]) then
			if thisProspect.depth == #pathParts then
				results[#results + 1] = fullPath
			elseif fs.isDir(fullPath) and thisProspect.depth < #pathParts then
				local newList = fs.list(fullPath)
				for i = 1, #newList do
					prospects[#prospects + 1] = {["parent"] = fullPath, ["depth"] = thisProspect.depth + 1, ["name"] = newList[i]}
				end
			end
		end
	end

	return results
end

fs.getDir = function(path)
	
end
